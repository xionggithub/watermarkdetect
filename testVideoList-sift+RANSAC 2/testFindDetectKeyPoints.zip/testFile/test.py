import numpy as np
import cv2
from matplotlib import pyplot as plt

#https://docs.opencv.org/3.0-beta/doc/py_tutorials/py_feature2d/py_feature_homography/py_feature_homography.html

MIN_MATCH_COUNT = 5

def test(rotationAngle, scale):
    w = 200 
    h = 200
    pts = np.float32([ [0,0],[0,h],[w,h],[w,0] ]).reshape(-1,1,2)
    print("原始矩形：\n"+str(pts)+ "\n")

    ang=np.pi*rotationAngle/2
    
    size = [w,h]
    rot_mat = np.array([[np.cos(0), np.sin(0), 0], [-np.sin(0), np.cos(0), 0], [0, 0 , scale]])
    
    if rotationAngle == 0 or rotationAngle == 4:
        size = [w,h]
        rot_mat = np.array([[np.cos(ang), np.sin(ang), 0], [-np.sin(ang), np.cos(ang), 0], [0, 0 , scale]])
    if rotationAngle == 1:
        size = [h,w]
        rot_mat = np.array([[np.cos(ang), np.sin(ang), 0], [-np.sin(ang), np.cos(ang), size[1]], [0, 0 , scale]])
        
    if rotationAngle == 2:
        size = [w,h]
        rot_mat = np.array([[np.cos(ang), np.sin(ang), size[0]], [-np.sin(ang), np.cos(ang), size[1]], [0, 0 , scale]])
        
    if rotationAngle == 3:
        size = [h,w]
        rot_mat = np.array([[np.cos(ang), np.sin(ang), size[0]], [-np.sin(ang), np.cos(ang), 0], [0, 0 , scale]])

    print("转换矩阵：\n"+str(rot_mat)+ "\n")

    dst = cv2.perspectiveTransform(pts,rot_mat)

    for points in dst:
        point = points[0]
        point = [int(point[0]), int(point[1])]
        points[0] = point
    print("转换后原始矩形：\n"+str(dst)+ "\n")


def find_watermark(sift, rotationAngle, figure, scale):
    imreadMode = 1 # 0 gray  1 color
    img1 = cv2.imread("logo.png",imreadMode)          # queryImage
    img2 = cv2.imread("logo_in_scene.jpg",imreadMode) # trainImage
    print(type(img2))
    rows = int(img2.shape[0]*0.2)
    cols = int(img2.shape[1]*0.5)
    # imgTmp = np.zeros((rows ,cols ,3),np.uint8)#生成一个空彩色图像
    print(rows)
    print(cols)
    imgTmp = np.zeros((rows ,cols, 3),np.uint8)#生成一个空彩色图像
    
    if imreadMode == 0:
        imgTmp = np.zeros((rows ,cols),np.uint8)#生成一个空彩色图像
    else:
        imgTmp = np.zeros((rows ,cols, 3),np.uint8)#生成一个空彩色图像
    
    print(imgTmp.shape)
    print(img2.shape)
    imgTmp[0:imgTmp.shape[0],0:imgTmp.shape[1]] = img2[0:imgTmp.shape[0],0:imgTmp.shape[1]]

    img2 = imgTmp

    #旋转90度
    ang=np.pi*rotationAngle/2
    # 0度
    size = [img1.shape[1]*scale, img1.shape[0]*scale]
    rot_mat = np.array([[np.cos(0)*scale, np.sin(0), 0], [-np.sin(0), np.cos(0)*scale, 0]])
    
    if rotationAngle == 0 or rotationAngle == 4:
        size = [img1.shape[1]*scale, img1.shape[0]*scale]
        print("--------0 4------------")
        rot_mat = np.array([[np.cos(ang)*scale, np.sin(ang),        0], [-np.sin(ang), np.cos(ang)*scale,       0]])
    
    if rotationAngle == 1:
        size = [img1.shape[0]*scale,img1.shape[1]*scale]
        print("--------1------------")
        rot_mat = np.array([[np.cos(ang), np.sin(ang)*scale,        0], [-np.sin(ang)*scale, np.cos(ang),  size[1]]])
        
    if rotationAngle == 2:
        size = [img1.shape[1]*scale,img1.shape[0]*scale]
        print("--------2------------")
        rot_mat = np.array([[np.cos(ang)*scale, np.sin(ang),  size[0]], [-np.sin(ang), np.cos(ang)*scale,  size[1]]])
        
    if rotationAngle == 3:
        size = [img1.shape[0]*scale,img1.shape[1]*scale]
        print("--------3------------")
        rot_mat = np.array([[np.cos(ang), np.sin(ang)*scale,  size[0]], [-np.sin(ang)*scale, np.cos(ang),       0]])
    print(rot_mat)
    print(scale)
    img1 = cv2.warpAffine(img1, rot_mat, (int(size[0]), int(size[1])))

    print("--------------------")

    # find the keypoints and descriptors with SIFT
    kp1, des1 = sift.detectAndCompute(img1,None)
    kp2, des2 = sift.detectAndCompute(img2,None)

    matches = []
    fast = True
    #快速匹配
    if fast == True:
        FLANN_INDEX_KDTREE = 0
        index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
        search_params = dict(checks = 50)

        flann = cv2.FlannBasedMatcher(index_params, search_params)
        matches = flann.knnMatch(des1,des2,k=2)
    else:
        #暴利匹配
        bf = cv2.BFMatcher()
        #返回k个最佳匹配
        matches = bf.knnMatch(des1, des2, k=2)

    print(len(matches))

    # store all the good matches as per Lowe's ratio test.
    good = []
    for m,n in matches:
        if m.distance < 0.7*n.distance:
            good.append(m)

    print(len(good))

    if len(good)>MIN_MATCH_COUNT:
        src_pts = np.float32([ kp1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)
        dst_pts = np.float32([ kp2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)

        M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC,5.0)
        matchesMask = mask.ravel().tolist()

        h,w = img1.shape[0:2]
        pts = np.float32([ [0,0],[0,h-1],[w-1,h-1],[w-1,0] ]).reshape(-1,1,2)
        dst = cv2.perspectiveTransform(pts,M)

        img2 = cv2.polylines(img2,[np.int32(dst)],True,255,3, cv2.LINE_AA)

    else:
        print("Not enough matches are found - %d/%d" % (len(good),MIN_MATCH_COUNT))
        matchesMask = None


    draw_params = dict(matchColor = (0,255,0), # draw matches in green color
                       singlePointColor = None,
                       matchesMask = matchesMask, # draw only inliers
                       flags = 2)

    img3 = cv2.drawMatches(img1,kp1,img2,kp2,good,None,**draw_params)
    plt.figure(figure*90)
    plt.imshow(img3, 'gray')
    return


if __name__ == '__main__':
    # Initiate SIFT detector
    # testM = True
    testM = False
    if testM == True:
        test(0, 1/2)
    else:
        sift = cv2.xfeatures2d.SIFT_create()
        angles = [0, 1, 2, 3 , 4]
        angles = [1]
        for angle in angles:
            find_watermark(sift, angle, angle, 1)
        plt.show()
